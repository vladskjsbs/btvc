import os
import hashlib
import base58
import aiohttp
import asyncio
import sys
import gc
from datetime import datetime
from mnemonic import Mnemonic
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend
import aiofiles
import ctypes
import time

# Глобальные счетчики
total_checked = 0
total_balance = 0
total_operations = 0
start_time = time.time()  # Запоминаем время начала работы скрипта

# Проверяем, запущен ли скрипт как .exe файл
is_exe = hasattr(sys, 'frozen')

if is_exe:
    operations_file = "operations_count.txt"
    if os.path.exists(operations_file):
        with open(operations_file, "r") as f:
            total_operations = int(f.read().strip())

def generate_key_and_addresses(mnemonic_phrase):
    seed = Mnemonic("english").to_seed(mnemonic_phrase)
    private_key_bytes = hashlib.sha256(seed).digest()
    private_key = ec.derive_private_key(int.from_bytes(private_key_bytes, byteorder="big"), ec.SECP256K1(), default_backend())
    
    public_key = private_key.public_key()
    serialized_public_key = public_key.public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    sha256_hash = hashlib.sha256(serialized_public_key).digest()
    ripemd160_hash = hashlib.new('ripemd160')
    ripemd160_hash.update(sha256_hash)
    hashed_public_key = ripemd160_hash.digest()

    addresses = {}

    # Generate P2PKH address
    extended_hashed_public_key = b'\x00' + hashed_public_key
    checksum = hashlib.sha256(hashlib.sha256(extended_hashed_public_key).digest()).digest()[:4]
    binary_address = extended_hashed_public_key + checksum
    addresses["P2PKH"] = base58.b58encode(binary_address).decode('utf-8')

    # Generate P2SH address
    extended_hashed_public_key = b'\x05' + hashed_public_key
    checksum = hashlib.sha256(hashlib.sha256(extended_hashed_public_key).digest()).digest()[:4]
    binary_address = extended_hashed_public_key + checksum
    addresses["P2SH"] = base58.b58encode(binary_address).decode('utf-8')

    # Generate P2WPKH address
    witness_version = b'\x00'
    witness_program = witness_version + hashed_public_key
    addresses["P2WPKH"] = base58.b58encode(witness_program).decode('utf-8')

    return private_key_bytes, addresses

async def get_balance(session, address):
    try:
        async with session.get(f"https://blockchain.info/q/addressbalance/{address}", timeout=10) as response:
            if response.status == 429:  # Too many requests
                return 0
            response.raise_for_status()
            return int(await response.text()) / 100000000
    except asyncio.TimeoutError:
        print("Запрос превысил время ожидания")
        return 0
    except aiohttp.ClientError as e:
        print("Ошибка при получении баланса:", e)
        return 0

async def save_wallet(mnemonic_phrase, addresses, balance, file_path):
    try:
        async with aiofiles.open(file_path, 'a') as f:
            await f.write(f"{datetime.now()}: Mnemonic Phrase: {mnemonic_phrase}\n")
            for address_type, address in addresses.items():
                await f.write(f"{address_type} Address: {address}\n")
            await f.write(f"Balance: {balance} BTC\n\n")
    except IOError as e:
        print("Ошибка при сохранении кошелька:", e)

async def update_status_bar():
    global total_checked, total_balance, start_time
    while True:
        elapsed_time = time.time() - start_time
        checks_per_second = total_checked / elapsed_time
        title = f"bvtc by stikcs (vladskjsbs)|| Проверок: {total_checked} ({checks_per_second:.2f} проверок/с) || Баланс: {total_balance:.8f} BTC"
        ctypes.windll.kernel32.SetConsoleTitleW(title)
        print(title)
        await asyncio.sleep(0.1)

async def worker(output_directory, session, activity_event):
    global total_checked, total_balance, total_operations
    while True:
        try:
            mnemonic_phrase = Mnemonic("english").generate(128)
            private_key_bytes, addresses = await asyncio.get_event_loop().run_in_executor(
                None, generate_key_and_addresses, mnemonic_phrase)

            bitcoin_address = addresses["P2PKH"]
            print(f"Сгенерированный адрес: {bitcoin_address}")

            balance = await get_balance(session, bitcoin_address)
            print(f"Баланс для адреса: {balance} BTC")

            total_checked += 1

            if balance > 0:
                print(f"Биткойн адрес - {bitcoin_address}, Баланс - {balance} BTC")
                file_name = f"btvc_{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
                file_path = os.path.join(output_directory, file_name)
                await save_wallet(mnemonic_phrase, addresses, balance, file_path)
                total_operations += 1
                total_balance += balance

                if is_exe:
                    with open(operations_file, "w") as f:
                        f.write(str(total_operations))

            # Очистка кеша каждые 1 миллион операций
            if total_checked % 1000000 == 0:
                print("Очистка кеша...")
                gc.collect()

            activity_event.set()
        except Exception as e:
            print("Произошла ошибка:", e)

        await asyncio.sleep(0.01)

async def monitor_activity(activity_event):
    while True:
        activity_event.clear()
        try:
            await asyncio.wait_for(activity_event.wait(), timeout=10)
        except asyncio.TimeoutError:
            print("Активность не обнаружена в течение 10 секунд. Перезапуск...")
            await asyncio.sleep(2)

async def start_workers(output_directory, session, num_workers=100):
    activity_event = asyncio.Event()
    tasks = []

    for _ in range(num_workers):
        tasks.append(asyncio.create_task(worker(output_directory, session, activity_event)))
    
    tasks.append(asyncio.create_task(update_status_bar()))
    tasks.append(asyncio.create_task(monitor_activity(activity_event)))

    await asyncio.gather(*tasks)

async def main():
    output_directory = "wallets"
    os.makedirs(output_directory, exist_ok=True)

    async with aiohttp.ClientSession() as session:
        await start_workers(output_directory, session)

if __name__ == "__main__":
    asyncio.run(main())
